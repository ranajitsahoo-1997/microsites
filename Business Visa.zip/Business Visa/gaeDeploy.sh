echo "Deploying to App engine"
gcloud app deploy app.yaml --project chillacsp1
echo "Services Deployed"